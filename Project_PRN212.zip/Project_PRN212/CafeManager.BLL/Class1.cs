﻿namespace CafeManager.BLL
{
    public class Class1
    {

    }
}
